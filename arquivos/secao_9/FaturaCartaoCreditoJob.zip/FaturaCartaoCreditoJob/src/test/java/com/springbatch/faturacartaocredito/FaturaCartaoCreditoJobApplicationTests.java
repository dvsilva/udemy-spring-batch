package com.springbatch.faturacartaocredito;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FaturaCartaoCreditoJobApplicationTests {

	@Test
	void contextLoads() {
	}

}
