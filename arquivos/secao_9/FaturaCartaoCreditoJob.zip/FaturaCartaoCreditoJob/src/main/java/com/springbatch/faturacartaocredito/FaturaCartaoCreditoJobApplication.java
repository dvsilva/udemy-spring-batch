package com.springbatch.faturacartaocredito;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FaturaCartaoCreditoJobApplication {

	public static void main(String[] args) {
		SpringApplication.run(FaturaCartaoCreditoJobApplication.class, args);
	}

}
