package com.springbatch.processadorclassifier;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProcessadorClassifierJobApplicationTests {

	@Test
	void contextLoads() {
	}

}
