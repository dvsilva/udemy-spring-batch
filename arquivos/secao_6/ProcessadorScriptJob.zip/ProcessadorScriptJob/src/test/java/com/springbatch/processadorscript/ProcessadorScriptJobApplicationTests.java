package com.springbatch.processadorscript;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProcessadorScriptJobApplicationTests {

	@Test
	void contextLoads() {
	}

}
