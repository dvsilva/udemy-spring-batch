package com.springbatch.enviopromocoesemail;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EnvioPromocoesClientesJobApplicationTests {

	@Test
	void contextLoads() {
	}

}
