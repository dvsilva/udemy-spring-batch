INSERT INTO cliente VALUES ("Joao", "Silva", "30", "joao@test.com");
INSERT INTO cliente VALUES ("Maria", "Silva", "30", "maria@test.com");