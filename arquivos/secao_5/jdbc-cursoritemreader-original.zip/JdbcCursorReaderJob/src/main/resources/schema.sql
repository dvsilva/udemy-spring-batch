CREATE TABLE cliente (
	nome TEXT,
	sobrenome TEXT,
	idade TEXT,
	email TEXT
);