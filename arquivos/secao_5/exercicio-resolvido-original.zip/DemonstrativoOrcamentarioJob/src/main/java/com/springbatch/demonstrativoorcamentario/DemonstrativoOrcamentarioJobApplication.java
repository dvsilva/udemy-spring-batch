package com.springbatch.demonstrativoorcamentario;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemonstrativoOrcamentarioJobApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemonstrativoOrcamentarioJobApplication.class, args);
	}

}
