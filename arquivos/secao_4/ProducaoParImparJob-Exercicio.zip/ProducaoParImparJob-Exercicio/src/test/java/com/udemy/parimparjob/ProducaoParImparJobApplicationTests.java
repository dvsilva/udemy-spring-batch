package com.udemy.parimparjob;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProducaoParImparJobApplicationTests {

	@Test
	void contextLoads() {
	}

}
