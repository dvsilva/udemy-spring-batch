package br.com.primeiroprojetospringbatch;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class T1PrimeiroProjetoSpringBatchApplication {

	public static void main(String[] args) {
		SpringApplication.run(T1PrimeiroProjetoSpringBatchApplication.class, args);
	}

}
