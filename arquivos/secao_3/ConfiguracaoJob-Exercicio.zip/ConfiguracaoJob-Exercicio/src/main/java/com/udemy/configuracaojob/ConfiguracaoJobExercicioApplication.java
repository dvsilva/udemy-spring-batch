package com.udemy.configuracaojob;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConfiguracaoJobExercicioApplication {

	public static void main(String[] args) {
		SpringApplication.run(ConfiguracaoJobExercicioApplication.class, args);
	}

}
