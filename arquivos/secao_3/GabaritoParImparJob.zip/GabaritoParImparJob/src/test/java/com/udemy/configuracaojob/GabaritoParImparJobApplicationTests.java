package com.udemy.configuracaojob;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GabaritoParImparJobApplicationTests {

	@Test
	void contextLoads() {
	}

}
