package com.springbatch.folhaponto;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FolhaPontoJobApplication {

	public static void main(String[] args) {
		SpringApplication.run(FolhaPontoJobApplication.class, args);
	}

}
