package com.springbatch.migracaodados;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MigracaoDadosJobApplicationTests {

	@Test
	void contextLoads() {
	}

}
